from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from flask_bcrypt import Bcrypt
from pymongo import MongoClient
from bson.objectid import ObjectId
from datetime import datetime
import re

from config import Config
from models import User, Prediction
from utils import predict_sentiment, get_sentiment_color, get_sentiment_icon, MODEL_LOADED

app = Flask(__name__)
app.config.from_object(Config)

# Initialize extensions
bcrypt = Bcrypt(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'
login_manager.login_message_category = 'info'

# MongoDB connection
client = MongoClient(app.config['MONGO_URI'])
db = client.get_database()

# Create indexes
db.users.create_index('email', unique=True)
db.users.create_index('username', unique=True)
db.predictions.create_index('user_id')
db.predictions.create_index('created_at')

@login_manager.user_loader
def load_user(user_id):
    return User.get_by_id(db, user_id)

# ==================== Routes ====================

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('home'))
    
    if request.method == 'POST':
        full_name = request.form.get('full_name', '').strip()
        username = request.form.get('username', '').strip().lower()
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')
        confirm_password = request.form.get('confirm_password', '')
        
        # Validation
        errors = []
        
        if not full_name or len(full_name) < 2:
            errors.append('Full name must be at least 2 characters.')
        
        if not username or len(username) < 3:
            errors.append('Username must be at least 3 characters.')
        elif not re.match(r'^[a-z0-9_]+$', username):
            errors.append('Username can only contain lowercase letters, numbers, and underscores.')
        elif User.get_by_username(db, username):
            errors.append('Username already exists.')
        
        if not email or not re.match(r'^[^\s@]+@[^\s@]+\.[^\s@]+$', email):
            errors.append('Please enter a valid email address.')
        elif User.get_by_email(db, email):
            errors.append('Email already registered.')
        
        if not password or len(password) < 6:
            errors.append('Password must be at least 6 characters.')
        
        if password != confirm_password:
            errors.append('Passwords do not match.')
        
        if errors:
            for error in errors:
                flash(error, 'danger')
            return render_template('register.html', 
                                 full_name=full_name, 
                                 username=username, 
                                 email=email)
        
        # Create user
        hashed_password = bcrypt.generate_password_hash(password).decode('utf-8')
        user = User.create_user(db, username, email, hashed_password, full_name)
        
        flash('Registration successful! Please login.', 'success')
        return redirect(url_for('login'))
    
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('home'))
    
    if request.method == 'POST':
        login_input = request.form.get('login_input', '').strip().lower()
        password = request.form.get('password', '')
        remember = request.form.get('remember', False)
        
        # Check if input is email or username
        if '@' in login_input:
            user = User.get_by_email(db, login_input)
        else:
            user = User.get_by_username(db, login_input)
        
        if user and bcrypt.check_password_hash(user.password, password):
            login_user(user, remember=remember)
            next_page = request.args.get('next')
            flash(f'Welcome back, {user.full_name}!', 'success')
            return redirect(next_page if next_page else url_for('home'))
        else:
            flash('Invalid username/email or password.', 'danger')
    
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out.', 'info')
    return redirect(url_for('home'))

@app.route('/predict', methods=['GET', 'POST'])
@login_required
def predict():
    result = None
    input_text = ''
    
    if request.method == 'POST':
        input_text = request.form.get('text', '').strip()
        
        if not input_text:
            flash('Please enter some text to analyze.', 'warning')
        elif len(input_text) < 3:
            flash('Text is too short for analysis.', 'warning')
        elif not MODEL_LOADED:
            flash('Prediction model not available. Please contact administrator.', 'danger')
        else:
            sentiment, confidence = predict_sentiment(input_text)
            
            if sentiment:
                # Save prediction to database
                Prediction.create_prediction(
                    db, 
                    current_user.id, 
                    input_text, 
                    sentiment, 
                    confidence
                )
                
                result = {
                    'text': input_text,
                    'sentiment': sentiment,
                    'confidence': round(confidence, 1) if confidence else None,
                    'color': get_sentiment_color(sentiment),
                    'icon': get_sentiment_icon(sentiment)
                }
            else:
                flash('Error analyzing text. Please try again.', 'danger')
    
    return render_template('predict.html', result=result, input_text=input_text)

@app.route('/predict/api', methods=['POST'])
@login_required
def predict_api():
    data = request.get_json()
    text = data.get('text', '').strip() if data else ''
    
    if not text:
        return jsonify({'error': 'No text provided'}), 400
    
    if not MODEL_LOADED:
        return jsonify({'error': 'Model not available'}), 503
    
    sentiment, confidence = predict_sentiment(text)
    
    if sentiment:
        Prediction.create_prediction(db, current_user.id, text, sentiment, confidence)
        return jsonify({
            'sentiment': sentiment,
            'confidence': round(confidence, 1) if confidence else None,
            'color': get_sentiment_color(sentiment),
            'icon': get_sentiment_icon(sentiment)
        })
    
    return jsonify({'error': 'Prediction failed'}), 500

@app.route('/history')
@login_required
def history():
    page = request.args.get('page', 1, type=int)
    per_page = 10
    
    predictions = Prediction.get_user_predictions(db, current_user.id, limit=100)
    stats = Prediction.get_user_stats(db, current_user.id)
    
    # Simple pagination
    total = len(predictions)
    start = (page - 1) * per_page
    end = start + per_page
    paginated_predictions = predictions[start:end]
    total_pages = (total + per_page - 1) // per_page
    
    # Add color and icon to predictions
    for pred in paginated_predictions:
        pred.color = get_sentiment_color(pred.sentiment)
        pred.icon = get_sentiment_icon(pred.sentiment)
    
    return render_template('history.html', 
                         predictions=paginated_predictions,
                         stats=stats,
                         page=page,
                         total_pages=total_pages,
                         total=total)

@app.route('/history/delete/<prediction_id>', methods=['POST'])
@login_required
def delete_prediction(prediction_id):
    if Prediction.delete_prediction(db, prediction_id, current_user.id):
        flash('Prediction deleted successfully.', 'success')
    else:
        flash('Error deleting prediction.', 'danger')
    return redirect(url_for('history'))

@app.route('/history/clear', methods=['POST'])
@login_required
def clear_history():
    db.predictions.delete_many({'user_id': current_user.id})
    flash('All prediction history cleared.', 'success')
    return redirect(url_for('history'))

# Error handlers
@app.errorhandler(404)
def not_found(e):
    return render_template('base.html', error='Page not found'), 404

@app.errorhandler(500)
def server_error(e):
    return render_template('base.html', error='Server error'), 500

# Context processor for templates
@app.context_processor
def utility_processor():
    return {
        'get_sentiment_color': get_sentiment_color,
        'get_sentiment_icon': get_sentiment_icon
    }

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)