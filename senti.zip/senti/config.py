import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'your-super-secret-key-change-in-production'
    MONGO_URI = os.environ.get('MONGO_URI') or 'mongodb://localhost:27017/twitter_sentiment_db'
    MODEL_PATH = './training/best_twitter_sentiment_model.pkl'
    VECTORIZER_PATH = './training/tfidf_vectorizer.pkl'