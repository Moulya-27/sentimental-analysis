from flask_login import UserMixin
from bson.objectid import ObjectId
from datetime import datetime

class User(UserMixin):
    def __init__(self, user_data):
        self.id = str(user_data['_id'])
        self.username = user_data['username']
        self.email = user_data['email']
        self.password = user_data['password']
        self.full_name = user_data.get('full_name', '')
        self.created_at = user_data.get('created_at', datetime.utcnow())

    @staticmethod
    def get_by_id(db, user_id):
        user_data = db.users.find_one({'_id': ObjectId(user_id)})
        if user_data:
            return User(user_data)
        return None

    @staticmethod
    def get_by_email(db, email):
        user_data = db.users.find_one({'email': email})
        if user_data:
            return User(user_data)
        return None

    @staticmethod
    def get_by_username(db, username):
        user_data = db.users.find_one({'username': username})
        if user_data:
            return User(user_data)
        return None

    @staticmethod
    def create_user(db, username, email, password, full_name):
        user_data = {
            'username': username,
            'email': email,
            'password': password,
            'full_name': full_name,
            'created_at': datetime.utcnow()
        }
        result = db.users.insert_one(user_data)
        user_data['_id'] = result.inserted_id
        return User(user_data)


class Prediction:
    def __init__(self, prediction_data):
        self.id = str(prediction_data['_id'])
        self.user_id = prediction_data['user_id']
        self.text = prediction_data['text']
        self.sentiment = prediction_data['sentiment']
        self.confidence = prediction_data.get('confidence', None)
        self.created_at = prediction_data.get('created_at', datetime.utcnow())

    @staticmethod
    def create_prediction(db, user_id, text, sentiment, confidence=None):
        prediction_data = {
            'user_id': user_id,
            'text': text,
            'sentiment': sentiment,
            'confidence': confidence,
            'created_at': datetime.utcnow()
        }
        result = db.predictions.insert_one(prediction_data)
        prediction_data['_id'] = result.inserted_id
        return Prediction(prediction_data)

    @staticmethod
    def get_user_predictions(db, user_id, limit=50):
        predictions = db.predictions.find(
            {'user_id': user_id}
        ).sort('created_at', -1).limit(limit)
        return [Prediction(p) for p in predictions]

    @staticmethod
    def get_user_stats(db, user_id):
        pipeline = [
            {'$match': {'user_id': user_id}},
            {'$group': {
                '_id': '$sentiment',
                'count': {'$sum': 1}
            }}
        ]
        results = list(db.predictions.aggregate(pipeline))
        stats = {'positive': 0, 'negative': 0, 'neutral': 0, 'total': 0}
        for r in results:
            sentiment = r['_id'].lower()
            if sentiment in stats:
                stats[sentiment] = r['count']
                stats['total'] += r['count']
        return stats

    @staticmethod
    def delete_prediction(db, prediction_id, user_id):
        result = db.predictions.delete_one({
            '_id': ObjectId(prediction_id),
            'user_id': user_id
        })
        return result.deleted_count > 0