import joblib
import re
from config import Config

# Load model and vectorizer
try:
    model = joblib.load(Config.MODEL_PATH)
    vectorizer = joblib.load(Config.VECTORIZER_PATH)
    MODEL_LOADED = True
except Exception as e:
    print(f"Error loading model: {e}")
    MODEL_LOADED = False
    model = None
    vectorizer = None

# Label mapping (adjust based on your trained model)
LABEL_MAPPING = {
    0: 'Negative',
    1: 'Neutral', 
    2: 'Positive'
}

REVERSE_LABEL_MAPPING = {v.lower(): k for k, v in LABEL_MAPPING.items()}

def clean_text(text):
    """Clean and preprocess text for prediction"""
    # Convert to lowercase
    text = text.lower()
    # Remove URLs
    text = re.sub(r'http\S+|www\S+|https\S+', '', text, flags=re.MULTILINE)
    # Remove mentions
    text = re.sub(r'@\w+', '', text)
    # Remove hashtags
    text = re.sub(r'#\w+', '', text)
    # Remove special characters and numbers
    text = re.sub(r'[^a-zA-Z\s]', '', text)
    # Remove extra whitespace
    text = ' '.join(text.split())
    return text

def predict_sentiment(text):
    """Predict sentiment of given text"""
    if not MODEL_LOADED:
        return None, None
    
    try:
        clean = clean_text(text)
        vector = vectorizer.transform([clean])
        prediction = model.predict(vector)[0]
        
        # Get confidence if available
        confidence = None
        if hasattr(model, 'predict_proba'):
            proba = model.predict_proba(vector)[0]
            confidence = max(proba) * 100
        elif hasattr(model, 'decision_function'):
            decision = model.decision_function(vector)[0]
            # Normalize decision function for approximate confidence
            if isinstance(decision, (list, tuple)) or hasattr(decision, '__iter__'):
                confidence = min(100, max(0, 50 + max(decision) * 10))
            else:
                confidence = min(100, max(0, 50 + abs(decision) * 10))
        
        sentiment = LABEL_MAPPING.get(prediction, str(prediction))
        return sentiment, confidence
    except Exception as e:
        print(f"Prediction error: {e}")
        return None, None

def get_sentiment_color(sentiment):
    """Get color class based on sentiment"""
    sentiment_lower = sentiment.lower() if sentiment else ''
    colors = {
        'positive': 'success',
        'negative': 'danger',
        'neutral': 'warning'
    }
    return colors.get(sentiment_lower, 'secondary')

def get_sentiment_icon(sentiment):
    """Get icon based on sentiment"""
    sentiment_lower = sentiment.lower() if sentiment else ''
    icons = {
        'positive': 'fa-smile',
        'negative': 'fa-frown',
        'neutral': 'fa-meh'
    }
    return icons.get(sentiment_lower, 'fa-question')